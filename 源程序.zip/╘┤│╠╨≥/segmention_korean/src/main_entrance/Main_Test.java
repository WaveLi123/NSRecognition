package main_entrance;
import SwingPackage.MainWindow;
public class Main_Test
{
	public static void main(String[] args)
	{
		new MainWindow().setVisible(true);
	}
}